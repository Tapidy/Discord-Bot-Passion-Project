import discord
import random
import asyncio
from discord.ext import commands

class rps(commands.Cog):
    print('RPS')
    def __init__(self, client):
        self.client = client

    @commands.command(name='rps',help='Rock Paper Scissors')
    async def rps(self, ctx):
        embed = discord.Embed(description="Pick Rock, Paper, or Scissors",color=0x00ff00)
        message = await ctx.send(embed=embed)
        msg1 = await self.client.wait_for('message', timeout=300.0)
        rsp = str(msg1.content)
        rsp = rsp.lower()
        if rsp.startswith('rock') or rsp.startswith('paper') or rsp.startswith('scissors'): 
          await ctx.message.channel.send(content='good choice...')
          await asyncio.sleep(2)
          ichs = random.choice(['Rock', 'Paper', 'Scissors'])
          await ctx.send(f'I chose {ichs}')
          if rsp == 'scissors' and ichs == 'Paper':
            await ctx.send(content='You Win!')
          if rsp == 'scissors' and ichs == 'Rock':
            await ctx.send(content='I Win!')
          if rsp == 'paper' and ichs == 'Rock':
            await ctx.send(content='You Win!')
          if rsp == 'paper' and ichs == 'Scissors':
            await ctx.send(content='I Win!')
          if rsp == 'rock' and ichs == 'Scissors':
            await ctx.send(content='You Win!')
          if rsp == 'rock' and ichs == 'Paper':
            await ctx.send(content='I Win!')
          if rsp == 'paper' and ichs == 'Paper':
            await ctx.send(content='We Tie!')
          if rsp == 'scissors' and ichs == 'Scissors':
            await ctx.send(content='We Tie!')
          if rsp == 'rock' and ichs == 'Rock':
            await ctx.send(content='We Tie!')
          await asyncio.sleep(1)
          await ctx.send(content='Good Game!')


def setup(client):
    client.add_cog(rps(client))
    